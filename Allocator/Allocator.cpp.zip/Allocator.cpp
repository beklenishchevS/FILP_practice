#include <cstddef>
#include <cstdlib>
#include "Allocator.h"
using namespace std;

class Block
{
public:
    Block* next = this;
    Block* prev = this;
    int selfSize;
    Block* self;
    Block(int size)
    {
        self = (Block*)malloc(size);
        selfSize = size;
    };

    bool isFree()
    {
        return selfSize >= 0;
    }
};



class Allocator
{
public:
    Block* block;
    size_t mem_size;
    Allocator(size_t size)
    {
        size_t mem_size = size;
        *block = Block(size);
    };

    void* alloc(size_t size)
    {
        if (size > mem_size)
        {
            throw 2;
        }
        Block* first = block;
        Block* current = block;
        while(current->next != first)
        {
            if (current->selfSize >= size and current->isFree())
            {
                Block* c = new Block(size);
                Block* d = new Block(current->selfSize - size);
                c->next = d;
                d->prev = c;
                c->prev = current->prev;
                d->next = current->next;
                current->prev->next = c;
                current->next->prev = d;
                block = d;
                return &c;
            }
            current = current->next;
        }
    }

    void dealloc(void* memPoint)
    {
        block = (Block*)memPoint;

    }
};